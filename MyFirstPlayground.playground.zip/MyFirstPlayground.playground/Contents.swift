import UIKit

var hello = "Hello, "
var name = "Nikita"
var age = "17"

var result = hello + "my name is " + name
result = result + "\nI am \(age) years old"
result = result + "\nI love coding"
print(result)
